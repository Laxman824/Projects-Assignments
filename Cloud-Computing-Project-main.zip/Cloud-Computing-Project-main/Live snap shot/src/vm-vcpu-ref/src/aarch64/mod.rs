#![cfg(target_arch = "aarch64")]

/// Helpers for setting up the interrupt controller.
pub mod interrupts;
