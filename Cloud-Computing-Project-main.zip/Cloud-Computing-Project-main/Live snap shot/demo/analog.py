'''
analogue clock on terminal with ascii characters
'''
import time
import math
import os
import sys


hour=0
minute=0
sec=0

