# shell script to print 3d rotating donut in terminal using bash
# using ascii characters only

# clear screen
clear

# set terminal to raw mode
stty raw

# set terminal to no echo
stty -echo

# set terminal to no line buffering
